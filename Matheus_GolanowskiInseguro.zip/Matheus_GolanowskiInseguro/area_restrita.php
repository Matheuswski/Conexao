<?php
    echo"<h1> &#128680  Area restrita &#128680 </h1>" ;

    echo "<p>Você não deveria estar aqui, mas conseguiu acessar devido a uma falha de segurança!</p>";

    echo "<p>Isso não mostra como ataques SQL injection podem comprometer sistemas sem proteção adequada.</p>";


?>